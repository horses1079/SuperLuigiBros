A simple hack made for people whos wants to play as Luigi in Super Mario Bros.
Replaced Mario text with Luigi, and replace Mario's graphics with Luigi's.
This is the 2nd hack made by Horses in 2023.